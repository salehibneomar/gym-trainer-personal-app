</body>
</html>

<?php
    DB::getDb()->destroyConn();
    ob_end_flush();
?>

